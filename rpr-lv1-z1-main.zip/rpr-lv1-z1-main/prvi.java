import java.util.Scanner;


public class Main {
    public static void main(String[] args) {
        System.out.println("Unesite prvi broj: ");
        Scanner scn = new Scanner(System.in);
        int n=scn.nextInt();
        System.out.println("Unesite drugi broj: " );
        int m=scn.nextInt();
        System.out.println("Prvi broj je: "+n);
        System.out.println(",a drugi broj je: "+m);


    }
}
