

public class Main {
    public static void main(String[] args) {
        ba.unsa.etf.rpr.Sat s = new ba.unsa.etf.rpr.Sat(15,30, 45);
        s.ispisi();
        s.sljedeci();
        s.ispisi();
        s.pomjeriZa(-48);
        s.ispisi();
        s.postavi(0,0,0);
        s.ispisi();
    }
}